package com.example.quranapp;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private PdfRenderer renderer;
    private PdfRenderer.Page currentPage;
    private ImageView pageImage;
    private TextView pageLabel;
    private ProgressBar progress;
    private int pageIndex = 0;
    private int pageCount = 305;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pageImage = findViewById(R.id.pageImage);
        pageLabel = findViewById(R.id.pageLabel);
        progress = findViewById(R.id.progress);
        if (savedInstanceState != null) pageIndex = savedInstanceState.getInt("page", 0);
        findViewById(R.id.prev).setOnClickListener(v -> showPage(pageIndex - 1));
        findViewById(R.id.next).setOnClickListener(v -> showPage(pageIndex + 1));
        findViewById(R.id.first).setOnClickListener(v -> showPage(0));
        findViewById(R.id.last).setOnClickListener(v -> showPage(pageCount - 1));
        try {
            File pdf = new File(getCacheDir(), "quran.pdf");
            if (!pdf.exists() || pdf.length() == 0) {
                try (InputStream in = getAssets().open("quran.pdf"); FileOutputStream out = new FileOutputStream(pdf)) {
                    byte[] buffer = new byte[1024 * 1024]; int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                }
            }
            ParcelFileDescriptor fd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(fd);
            pageCount = renderer.getPageCount();
            showPage(pageIndex);
        } catch (Exception e) {
            progress.setVisibility(View.GONE);
            Toast.makeText(this, "تعذر فتح ملف القرآن الكريم", Toast.LENGTH_LONG).show();
        }
    }

    private void showPage(int index) {
        if (renderer == null) return;
        if (index < 0 || index >= renderer.getPageCount()) return;
        pageIndex = index;
        progress.setVisibility(View.VISIBLE);
        if (currentPage != null) { currentPage.close(); currentPage = null; }
        currentPage = renderer.openPage(pageIndex);
        int targetWidth = Math.max(900, getResources().getDisplayMetrics().widthPixels * 2);
        float ratio = (float) currentPage.getHeight() / currentPage.getWidth();
        int targetHeight = Math.max(1200, (int)(targetWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE);
        currentPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        pageImage.setImageBitmap(bitmap);
        pageLabel.setText("الصفحة " + (pageIndex + 1) + " من " + renderer.getPageCount());
        progress.setVisibility(View.GONE);
    }

    @Override protected void onSaveInstanceState(Bundle out) { out.putInt("page", pageIndex); super.onSaveInstanceState(out); }
    @Override protected void onDestroy() { if (currentPage != null) currentPage.close(); if (renderer != null) renderer.close(); super.onDestroy(); }
}
